# My Ebook Library — MVP

A responsive, Kindle-inspired PDF library built as a static web app.

## Included in this MVP
- Responsive mobile/desktop interface
- Import PDF files (up to 100 MB per file in this MVP)
- Local browser storage using IndexedDB
- PDF reading powered by Mozilla PDF.js
- Saves last-read page
- Page bookmarks
- Library search and remove
- Light/dark reading interface

## Not included yet
- Cloud sync / Supabase account and storage
- PDF-to-EPUB conversion
- OCR for scanned PDFs
- EPUB reading
- Annotation/highlighting

These are planned for the next iterations. Current files stay in the browser/device where they were added. Clearing browser site data can delete local books. Keep your original PDFs backed up.

## Run locally
Open `index.html` through a local static server (recommended), not by double-clicking it. For example:
`python -m http.server 8000`
Then visit `http://localhost:8000`.

## Deploy to Netlify
1. Create a GitHub repository named `my-ebook-library`.
2. Upload `index.html` and this `README.md` to the repository root.
3. In Netlify, choose **Add new site → Import an existing project**.
4. Connect GitHub and select `my-ebook-library`.
5. Build command: leave blank. Publish directory: `.` (repository root).
6. Deploy. Netlify will provide a public URL.

## Important
PDF.js is loaded from cdnjs, so the app needs an internet connection to load the PDF engine. Once loaded, imported PDF bytes are stored locally in IndexedDB. The app does not upload PDFs anywhere in this MVP.
