# My Ebook Library v2 MVP

## Included
- Responsive Kindle-inspired bookshelf
- Import PDF and EPUB
- PDF original fixed-layout reader
- PDF text extraction into reflowable text, page by page
- Adjustable font family, font size, line spacing, white/sepia/dark backgrounds
- Multiple bookmarks
- Save selected text as highlight notes
- Open selected text in Google Translate or Oxford Learner's Dictionaries
- EPUB reader powered by EPUB.js
- Local IndexedDB storage

## Limitations
- Local storage only: no cloud sync or cross-device backup yet.
- Text extraction works best on text-based PDFs. Scanned PDFs need OCR.
- Reflow is best-effort and may not preserve columns, tables, footnotes, or images.
- Highlights are saved as text notes; persistent in-text highlighting is a later enhancement.
- Google and Oxford open as external websites, not API integrations.
- PDF.js and EPUB.js load from CDNs.

## Deploy
Upload `index.html` to the root of a GitHub repository and import it in Netlify.
Build command: blank. Publish directory: `.`.
